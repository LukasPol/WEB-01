

var express = require('express');
var bp      = require('body-parser');
var app     = express();
app.use(express.static('views'));
app.use(bp.urlencoded(
          {extended : false}));

app.listen(3000, () => { 
    console.log("Server OK!"); });

app.get('/', (req, res) => {
    res.send('<h1>Oi</h1>');
});

app.get('/aluno/:nome', (req, res) => {
    var nm = req.params.nome;
    res.send('<p>' + nm + '</p>');
}); 

app.post('/aluno', (req, res) => {
    var nome = req.body.nome;
    res.send(nome);
});

app.use(function(err, req, res, next) {
    console.error(err.stack);
    res.status(400).send('Something broke!');
});